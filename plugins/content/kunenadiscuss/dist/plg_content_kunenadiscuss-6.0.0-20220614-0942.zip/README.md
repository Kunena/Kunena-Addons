# Kunena Discuss Plugin README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING Kunena Discuss @kunenaversion@!

## INTRODUCTION

Kunena Discuss enables your site visitors to discuss your content articles in designated forum categories.

Requirements: Joomla! 4.0, Kunena Forum 4.0


