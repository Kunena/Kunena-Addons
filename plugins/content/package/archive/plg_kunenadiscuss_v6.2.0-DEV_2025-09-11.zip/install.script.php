<?php

/**
 * Kunena Discuss Plugin
 *
 * @package       Kunena.plg_content_kunenadiscuss
 *
 * @copyright     @kunenacopyright@
 * @license       http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link          https://www.kunena.org
 **/

defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\Adapter\ComponentAdapter;
use Joomla\CMS\Installer\InstallerScript;
use Joomla\Database\Exception\ExecutionFailureException;

/**
 * @package     Kunena
 *
 * @since       Kunena
 */
class PlgContentKunenadiscussInstallerScript extends InstallerScript
{
    /**
     * The extension name. This should be set in the installer script.
     *
     * @var    string
     * @since  5.4.0
     */
    protected $extension = 'plg_content_kunenadiscuss';

    /**
     * Minimum PHP version required to install the extension
     *
     * @var    string
     * @since  5.4.0
     */
    protected $minimumPhp = '8.1';

    /**
     * Minimum Joomla! version required to install the extension
     *
     * @var    string
     * @since  6.0.0
     */
    protected $minimumJoomla = '5.3.2';

    /**
     * List of required PHP extensions.
     *
     * @var array
     * @since Kunena
     */
    protected $extensions = ['dom', 'gd', 'json', 'pcre', 'SimpleXML'];

    /**
     * Function called before extension installation/update/removal procedure commences
     *
     * @param   string            $type    The type of change (install, update or discover_install, not uninstall)
     * @param   InstallerAdapter  $parent  The class calling this method
     *
     * @return  boolean  True on success
     * @since   Kunena 6.5
     */
    public function preflight($type, $parent): bool
    {
        if (!parent::preflight($type, $parent)) {
            return false;
        }

        $manifest = $this->getItemArray('manifest_cache', '#__extensions', 'name', $this->extension);

        // Check whether we have an old release installed and skip this check when this here is the initial install.
        if (!isset($manifest['version'])) {
            return true;
        }

        $oldRelease = $manifest['version'];

        if (version_compare($oldRelease, '6.1', '<')) {
            // Delete old folder to start fresh
            $this->deleteFolders[] = JPATH_SITE . '/plugins/content/kunenadiscuss/css';
            $this->deleteFolders[] = JPATH_SITE . '/plugins/content/kunenadiscuss/language';
            $this->deleteFolders[] = JPATH_SITE . '/plugins/content/kunenadiscuss/tmpl';
            $this->deleteFolders[] = JPATH_SITE . '/media/plg_content_kunenadiscuss';
        }

        $this->deleteFiles[] = JPATH_SITE . '/plugins/content/kunenadiscuss/kunenadiscuss.php';
        $this->deleteFiles[] = JPATH_SITE . '/plugins/content/kunenadiscuss/src/Helper/KunenaDiscussInstallerHelper.php';

        $this->removeFiles();

        return true;
    }
}
